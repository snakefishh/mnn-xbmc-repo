﻿#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc

xbmc.executebuiltin('XBMC.RunScript(script.service.jtvtoxmltv, start)')
